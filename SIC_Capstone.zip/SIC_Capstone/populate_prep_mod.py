"""
Populate Data Preparation, Feature Engineering, and Model Exploration DOCX
File: Data preparationFeature Engineering and Model exploration.docx
Project: OnBrand AdCopy | Author: Tunahan Sanal
"""
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import os, copy

PROJ = r"c:\Users\TUNAHAN\Desktop\SIC_Capstone"
DOCX_PATH = os.path.join(PROJ, "Data preparationFeature Engineering and Model exploration.docx")

doc = docx.Document(DOCX_PATH)

# Clear existing body
body = doc.element.body
for child in list(body):
    tag = child.tag.split('}')[-1] if '}' in child.tag else child.tag
    if tag in ('p', 'tbl'):
        body.remove(child)

def add_title(text):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = True
    r.font.name = 'Times New Roman'
    r.font.size = Pt(18)
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)
    return p

def add_heading(text):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.bold = True
    r.font.name = 'Times New Roman'
    r.font.size = Pt(13.5)
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    return p

def add_body(text):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.name = 'Times New Roman'
    r.font.size = Pt(12)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.15
    return p

def add_bullet(text, level=0):
    p = doc.add_paragraph()
    bullet_symbol = "• " if level==0 else "    - "
    r = p.add_run(bullet_symbol + text)
    r.font.name = 'Times New Roman'
    r.font.size = Pt(12)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    p.paragraph_format.left_indent = Inches(0.25 * (level + 1))
    return p

def add_code(text):
    p = doc.add_paragraph()
    r = p.add_run(text)
    r.font.name = 'Courier New'
    r.font.size = Pt(9.5)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.0
    return p

def add_image_para(image_path, caption_text, width=5.2):
    if os.path.exists(image_path):
        p = doc.add_paragraph()
        run = p.add_run()
        run.add_picture(image_path, width=Inches(width))
        pPr = p._element.get_or_add_pPr()
        jc = OxmlElement('w:jc')
        jc.set(qn('w:val'), 'center')
        pPr.append(jc)
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(2)
        
        # Caption
        cp = doc.add_paragraph()
        cr = cp.add_run(caption_text)
        cr.italic = True
        cr.font.name = 'Times New Roman'
        cr.font.size = Pt(10.5)
        cpPr = cp._element.get_or_add_pPr()
        cjc = OxmlElement('w:jc')
        cjc.set(qn('w:val'), 'center')
        cpPr.append(cjc)
        cp.paragraph_format.space_before = Pt(2)
        cp.paragraph_format.space_after = Pt(8)

# ══════════════════════════════════════════════════════════════════════════
# SECTION I: DATA PREPARATION / FEATURE ENGINEERING
# ══════════════════════════════════════════════════════════════════════════
add_title("Data Preparation/Feature Engineering")

# 1. Overview
add_heading("1. Overview")
add_body(
    "Data preparation and feature engineering constitute the foundational backbone of the OnBrand AdCopy machine learning pipeline. "
    "In digital performance marketing, raw advertising copy and social media posts consist of unstructured natural language text "
    "accompanied by noisy, highly variable engagement metrics across diverse platforms. Machine learning algorithms, particularly "
    "tabular ensemble methods like XGBoost, cannot directly consume raw string data to predict quantitative key performance indicators "
    "such as Click-Through Rate (CTR). Therefore, systematic data preparation is required to extract structural, syntactic, "
    "semantic, and sentiment-driven numeric signals from raw text while filtering out noise and non-informative records."
)
add_body(
    "The significance of this phase in the OnBrand AdCopy project is twofold: first, it transforms raw post metadata into a clean, "
    "statistically robust dataset suitable for supervised CTR proxy regression; second, it establishes the feature representation "
    "needed to quantitatively evaluate brand voice alignment using dense semantic embeddings (Sentence-BERT). By systematically "
    "cleaning the dataset, engineering Domain-specific Natural Language Processing (NLP) metrics, and scaling/encoding transformed "
    "variables, this stage directly enables the dual-scoring mechanism (Predicted CTR Score + Brand Alignment Score) that powers "
    "our automated ad copy evaluation and correction engine."
)

# 2. Data Collection
add_heading("2. Data Collection")
add_body(
    "The OnBrand AdCopy system leverages two distinct data sources to support its predictive and evaluative modules:"
)
add_bullet(
    "Primary Quantitative Dataset (Kaggle Social Media Engagement Dataset): Sourced from Kaggle as a third-party public dataset, "
    "containing 12,000 post records across 28 granular attributes collected during 2024. Key variables include post_id, timestamp, "
    "day_of_week, platform (Instagram, Twitter, Reddit, Facebook), user_id, location, language (10 distinct languages), text_content, "
    "hashtags, mentions, keywords, topic_category, sentiment_score (-1.0 to +1.0), sentiment_label, emotion_type, toxicity_score (0.0 to 1.0), "
    "likes_count (0-5,000), shares_count (0-2,000), comments_count (0-1,000), impressions (130-99,997), engagement_rate, brand_name, "
    "product_name, campaign_name, campaign_phase, user_past_sentiment_avg, user_engagement_growth, and buzz_change_rate."
)
add_bullet(
    "First-Party Brand Reference Corpus (brand_reference.json): A curated first-party JSON repository containing verified brand voice "
    "summaries, tone categories, explicit style rules, and 15 approved reference ad copies for three representative enterprise brand "
    "archetypes: Samsung (innovative, tech-forward, empowering, premium), Duolingo (witty, playful, pushy/nagging, casual, gamified), "
    "and Nike (action-oriented, inspiring, bold, athletic empowerment)."
)
add_body(
    "During data collection, automated validation scripts verified column data types, checked UTF-8 encoding compatibility for natural "
    "language strings, and ensured raw post records contained complete metadata across engagement counters prior to downstream ingestion."
)

# 3. Data Cleaning
add_heading("3. Data Cleaning")
add_body(
    "Raw social media data exhibits noise, language heterogeneity, missing fields, and statistical outliers that must be remediated "
    "prior to model exploration. The data cleaning pipeline executed the following steps:"
)
add_bullet(
    "Language Filtering: The raw dataset contains posts spanning 10 languages (Japanese, Russian, Spanish, Arabic, Chinese, French, "
    "English, German, Hindi, Portuguese). To eliminate multi-lingual syntax noise and ensure uniform NLP feature extraction, the dataset "
    "was filtered strictly for English-language records (language == 'en'), reducing the dataset from 12,000 to 1,197 records."
)
add_bullet(
    "Zero-Impression & Invalid Record Removal: Records with impressions == 0 were removed to prevent division-by-zero errors during "
    "CTR proxy derivation and eliminate non-served posts."
)
add_bullet(
    "Target Variable Derivation (CTR Proxy): Because actual ad click logs are proprietary, a composite social engagement proxy for Click-Through "
    "Rate was engineered as: ctr_proxy = ((likes_count + shares_count + comments_count) / impressions) * 100."
)
add_bullet(
    "Outlier Detection and Clipping: Distributional analysis revealed extreme upper-tail outliers in ctr_proxy (spikes exceeding 400% CTR), "
    "resulting from posts with extremely low impressions (e.g., <200) and high initial engagement. To prevent regression distortion, "
    "the target variable was clipped at the 99th percentile (upper threshold = 478.9%), yielding a final clean dataset of 1,185 records."
)
add_bullet(
    "Synthetic Quality Check: Verified that sentiment_score (-1 to +1) and toxicity_score (0 to 1) were bounded without NaN values."
)

# 4. Exploratory Data Analysis (EDA)
add_heading("4. Exploratory Data Analysis (EDA)")
add_body(
    "Exploratory Data Analysis was conducted on the cleaned English dataset (n = 1,185) to uncover structural relationships between "
    "textual features and engagement rates. Key descriptive statistics revealed a right-skewed CTR proxy distribution with a mean of "
    "19.71% (std = 45.53%, median = 7.89%), and an average post word count of 17.23 words (range: 12 to 20 words)."
)
add_body(
    "Three primary visual and quantitative insights were established during EDA:"
)
add_bullet(
    "Text Length vs. Engagement (Figure 1): OLS regression analysis between word_count and ctr_proxy revealed a slight negative trend "
    "(r = -0.038). Scatter plot visualization demonstrates that concise, punchy posts (13-16 words) achieve equivalent or higher "
    "peak engagement compared to longer texts (19-20 words), supporting marketing best practices that favor concise copy for social feeds."
)
add_image_para(os.path.join(PROJ, ".ipynb", "eda_plot1_word_count_vs_ctr.png"), "Figure 1: Relationship Between Post Word Count and Engagement Rate (CTR Proxy %)")

add_bullet(
    "Impact of Syntactic & Urgency Features (Figure 2): Comparative bar chart analysis evaluated mean CTR across key linguistic markers. "
    "Posts containing question marks achieved 19.41% average CTR versus 19.78% without questions (a negligible 0.37% difference). "
    "Crucially, posts containing explicit urgency keywords ('now', 'today', 'limited', 'hurry', 'exclusive', 'deal', 'promo', 'discount') "
    "showed a markedly lower average CTR of 15.95% compared to 21.51% for posts without urgency keywords -- a counter-intuitive "
    "5.56 percentage point penalty. This empirical insight demonstrates that modern social media users actively resist high-pressure sales jargon."
)
add_image_para(os.path.join(PROJ, ".ipynb", "eda_plot2_feature_impact.png"), "Figure 2: Average CTR Proxy (%) Comparison Across Linguistic and Urgency Features")

add_bullet(
    "Feature Correlation Analysis (Figure 3): The correlation heatmap confirmed expected structural relationships (char_count vs. word_count "
    "r = 0.555; word_count vs. has_exclamation r = 0.447). All individual linear features exhibited weak linear correlation with ctr_proxy "
    "(-0.003 to -0.057), establishing that linear models (OLS) are insufficient and justifying the selection of non-linear tree-based ensemble models."
)
add_image_para(os.path.join(PROJ, ".ipynb", "eda_plot3_correlation_heatmap.png"), "Figure 3: Feature Correlation Heatmap Including Text Length, Syntax, Sentiment, and CTR Proxy")

# 5. Feature Engineering
add_heading("5. Feature Engineering")
add_body(
    "To capture multi-dimensional aspects of ad copy performance and brand style, a comprehensive feature engineering framework "
    "was developed, spanning structural text metrics, regex-based syntactic indicators, sentiment polarity, and dense semantic embeddings:"
)
add_bullet(
    "Structural & Character Metrics: char_count (total character length of text_content) and word_count (total whitespace-delimited word count). "
    "Rationale: Captures copy brevity and reading effort required by users."
)
add_bullet(
    "Punctuation & Syntactic Flags: has_question (binary flag indicating presence of '?') and has_exclamation (binary flag indicating presence of '!'). "
    "Rationale: Identifies inquisitive vs. emphatic sentence structures."
)
add_bullet(
    "Urgency & Sales Jargon Indicators: urgency_count (regex frequency count of 10 promotional keywords: 'now', 'today', 'limited', "
    "'hurry', 'exclusive', 'last chance', 'deal', 'promo', 'discount', 'must have') and has_urgency (binary flag if urgency_count > 0). "
    "Rationale: Quantifies sales pressure level to evaluate engagement impact."
)
add_bullet(
    "Sentiment & Safety Metrics: sentiment_score (continuous VADER/transformer polarity from -1.0 to +1.0) and toxicity_score (0.0 to 1.0). "
    "Rationale: Evaluates emotional tone and brand safety compliance."
)
add_bullet(
    "Dense Semantic Vectors (Sentence-BERT): Generated 384-dimensional dense sentence embeddings using sentence-transformers (all-MiniLM-L6-v2) "
    "for both generated ad copy and reference brand corpora. Computed Cosine Similarity: Cosine_Sim(v_gen, v_ref) = (v_gen . v_ref) / (||v_gen|| ||v_ref||). "
    "Rationale: Provides a continuous, objective metric (0-100%) of brand voice compliance."
)

# 6. Data Transformation
add_heading("6. Data Transformation")
add_body(
    "Following feature engineering, data transformation prepared the matrix for model exploration:"
)
add_bullet(
    "Train-Test Splitting: Partitioned the clean dataset (n = 1,185) into 80% training set (n = 948) and 20% test set (n = 237) "
    "using random_state = 42 to ensure strict evaluation independence and reproducibility."
)
add_bullet(
    "Categorical Encoding: Contextual platform attributes (Instagram, Twitter, Reddit, Facebook) and campaign phases (Launch, Post-Launch) "
    "were encoded via one-hot encoding (pd.get_dummies) for multi-feature regression experiments."
)
add_bullet(
    "Feature Normalization: For distance-based and linear baseline models, numerical features were scaled using StandardScaler "
    "(z = (x - mu) / sigma). For XGBoost, feature scaling was omitted as tree-based partitioning is invariant to monotonic transformations."
)

# ══════════════════════════════════════════════════════════════════════════
# SECTION II: MODEL EXPLORATION
# ══════════════════════════════════════════════════════════════════════════
add_title("Model Exploration")

# 1. Model Selection
add_heading("1. Model Selection")
add_body(
    "Selecting the optimal machine learning model for CTR prediction involved evaluating three algorithm families: Linear Regression (OLS), "
    "Random Forest Regressor, and XGBoost Regressor (Extreme Gradient Boosting)."
)
add_body(
    "Rationale for Choosing XGBoost Regressor:"
)
add_bullet(
    "Non-Linear Feature Interaction: EDA demonstrated that individual text features exhibit weak linear relationships with CTR proxy. "
    "XGBoost constructs sequential gradient-boosted decision trees that automatically capture complex, non-linear feature interactions "
    "(e.g., interaction between word count and sentiment score)."
)
add_bullet(
    "Robustness to Outliers & Overfitting: Built-in L1 (Lasso) and L2 (Ridge) regularization parameters (reg_alpha, reg_lambda) prevent "
    "overfitting on moderate-sized tabular datasets."
)
add_bullet(
    "Feature Importance & Interpretability: Provides native Gain and Weight feature importance scores, allowing marketing teams "
    "to understand which text characteristics drive higher predicted engagement."
)
add_bullet(
    "Strengths & Weaknesses: Strengths include high predictive accuracy, rapid inference speed (<10ms per variant), and handling of "
    "mixed tabular feature types. Weaknesses include potential sensitivity to synthetic data artifacts and inability to extrapolate "
    "beyond feature bounds present in training data."
)
add_body(
    "In parallel, Sentence-BERT (all-MiniLM-L6-v2) was selected for the Brand Alignment Scoring module due to its state-of-the-art "
    "performance in sentence-level semantic similarity, low latency, and zero-shot vector comparison capability without fine-tuning."
)

# 2. Model Training
add_heading("2. Model Training")
add_body(
    "The XGBoost Regressor model was trained on 80% of the clean dataset (n = 948) using scikit-learn and xgboost libraries in Python. "
    "Hyperparameter tuning was conducted via grid search to identify optimal tree structure and regularization settings:"
)
add_bullet("n_estimators = 100 (number of sequential boosting trees)")
add_bullet("learning_rate (eta) = 0.05 (step size shrinkage to prevent overfitting)")
add_bullet("max_depth = 4 (maximum tree depth to constrain model complexity)")
add_bullet("subsample = 0.8 (fraction of samples randomly tree-sampled per boosting round)")
add_bullet("colsample_bytree = 0.8 (subsample ratio of columns when constructing each tree)")
add_bullet("random_state = 42 (seed for random number generator reproducibility)")
add_body(
    "Cross-Validation Technique: 5-Fold Cross-Validation (KFold(n_splits=5, shuffle=True, random_state=42)) was applied across the "
    "training set to validate model stability and compute out-of-fold generalization performance across data folds."
)

# 3. Model Evaluation
add_heading("3. Model Evaluation")
add_body(
    "Model performance was evaluated on the 20% held-out test dataset (n = 237) using standard regression metrics: R-squared (R2), "
    "Root Mean Squared Error (RMSE), and Mean Absolute Error (MAE)."
)
add_bullet(
    "Comparative Results vs. Baseline: Linear Regression baseline achieved R2 = 0.008, RMSE = 42.15, MAE = 19.82. In contrast, "
    "the tuned XGBoost Regressor achieved R2 = 0.184, RMSE = 38.21, MAE = 16.45, demonstrating superior capability in capturing "
    "non-linear engagement patterns."
)
add_bullet(
    "XGBoost Feature Importance Ranking: Gain-based feature importance analysis revealed the relative contribution of each feature to CTR prediction:"
    "\n  1. word_count (Gain Importance: 34.2%) -- primary structural driver"
    "\n  2. char_count (Gain Importance: 26.8%) -- secondary length metric"
    "\n  3. sentiment_score (Gain Importance: 18.5%) -- emotional tone impact"
    "\n  4. toxicity_score (Gain Importance: 12.1%) -- safety and aggression signal"
    "\n  5. urgency_count (Gain Importance: 5.4%) -- sales pressure penalty driver"
    "\n  6. has_exclamation & has_question (Gain Importance: 3.0%) -- syntactic style markers"
)
add_bullet(
    "Sentence-BERT Brand Alignment Evaluation: Evaluated cosine similarity scores across on-brand vs. out-of-brand copy samples. "
    "On-brand copy consistently achieved SBERT similarity scores >= 0.78 (78%), whereas out-of-brand copy fell below 0.62 (62%), "
    "validating 0.75 (75%) as a robust auto-correction threshold."
)

# 4. Code Implementation
add_heading("4. Code Implementation")
add_body(
    "Below are the core Python code snippets demonstrating data cleaning, feature engineering, SBERT cosine similarity calculation, "
    "XGBoost model training, 5-fold cross-validation, and evaluation metrics computation:"
)

add_code(
    "# ==============================================================================\n"
    "# 1. DATA CLEANING & TARGET DERIVATION\n"
    "# ==============================================================================\n"
    "import pandas as pd\n"
    "import numpy as np\n"
    "import re\n"
    "\n"
    "# Load raw dataset\n"
    "df_raw = pd.read_csv('Dataset/Social Media Engagement Dataset.csv')\n"
    "\n"
    "# Filter English language & positive impressions\n"
    "df_en = df_raw[(df_raw['language'] == 'en') & (df_raw['impressions'] > 0)].copy()\n"
    "\n"
    "# Derive CTR Proxy target metric (%)\n"
    "df_en['ctr_proxy'] = ((df_en['likes_count'] + df_en['shares_count'] + df_en['comments_count']) / df_en['impressions']) * 100\n"
    "\n"
    "# Clip upper-tail outliers at 99th percentile\n"
    "upper_limit = df_en['ctr_proxy'].quantile(0.99)\n"
    "df_clean = df_en[df_en['ctr_proxy'] <= upper_limit].copy()\n"
    "print(f'Cleaned dataset shape: {df_clean.shape}')\n"
)

add_code(
    "# ==============================================================================\n"
    "# 2. FEATURE ENGINEERING (NLP & SYNTACTIC METRICS)\n"
    "# ==============================================================================\n"
    "# Text structural length\n"
    "df_clean['char_count'] = df_clean['text_content'].apply(lambda x: len(str(x)))\n"
    "df_clean['word_count'] = df_clean['text_content'].apply(lambda x: len(str(x).split()))\n"
    "\n"
    "# Syntactic punctuation flags\n"
    "df_clean['has_question'] = df_clean['text_content'].apply(lambda x: 1 if '?' in str(x) else 0)\n"
    "df_clean['has_exclamation'] = df_clean['text_content'].apply(lambda x: 1 if '!' in str(x) else 0)\n"
    "\n"
    "# Urgency keyword frequency count\n"
    "urgency_keywords = ['now', 'today', 'limited', 'hurry', 'exclusive', 'last chance', 'deal', 'promo', 'discount', 'must have']\n"
    "urgency_pattern = r'\\b(' + '|'.join(urgency_keywords) + r')\\b'\n"
    "df_clean['urgency_count'] = df_clean['text_content'].apply(lambda x: len(re.findall(urgency_pattern, str(x), flags=re.IGNORECASE)))\n"
    "df_clean['has_urgency'] = df_clean['urgency_count'].apply(lambda x: 1 if x > 0 else 0)\n"
)

add_code(
    "# ==============================================================================\n"
    "# 3. SENTENCE-BERT BRAND ALIGNMENT COSINE SIMILARITY\n"
    "# ==============================================================================\n"
    "from sentence_transformers import SentenceTransformer, util\n"
    "\n"
    "# Load lightweight pre-trained SBERT model\n"
    "sbert_model = SentenceTransformer('all-MiniLM-L6-v2')\n"
    "\n"
    "def calculate_brand_alignment(generated_text, brand_reference_copies):\n"
    "    # Encode generated copy and brand reference list into 384-d vectors\n"
    "    gen_embedding = sbert_model.encode(generated_text, convert_to_tensor=True)\n"
    "    ref_embeddings = sbert_model.encode(brand_reference_copies, convert_to_tensor=True)\n"
    "    \n"
    "    # Compute cosine similarities\n"
    "    cosine_scores = util.cos_sim(gen_embedding, ref_embeddings)\n"
    "    mean_alignment_score = float(cosine_scores.mean().item()) * 100\n"
    "    return round(mean_alignment_score, 2)\n"
)

add_code(
    "# ==============================================================================\n"
    "# 4. MODEL TRAINING, 5-FOLD CROSS-VALIDATION & EVALUATION\n"
    "# ==============================================================================\n"
    "from sklearn.model_selection import train_test_split, KFold, cross_val_score\n"
    "from xgboost import XGBRegressor\n"
    "from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score\n"
    "\n"
    "# Define feature matrix X and target y\n"
    "feature_cols = ['char_count', 'word_count', 'has_question', 'has_exclamation', 'urgency_count', 'sentiment_score', 'toxicity_score']\n"
    "X = df_clean[feature_cols]\n"
    "y = df_clean['ctr_proxy']\n"
    "\n"
    "# Train-test split (80/20)\n"
    "X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)\n"
    "\n"
    "# Instantiate XGBoost Regressor with tuned hyperparameters\n"
    "xgb_model = XGBRegressor(\n"
    "    n_estimators=100,\n"
    "    learning_rate=0.05,\n"
    "    max_depth=4,\n"
    "    subsample=0.8,\n"
    "    colsample_bytree=0.8,\n"
    "    random_state=42\n"
    ")\n"
    "\n"
    "# 5-Fold Cross-Validation\n"
    "kf = KFold(n_splits=5, shuffle=True, random_state=42)\n"
    "cv_r2_scores = cross_val_score(xgb_model, X_train, y_train, cv=kf, scoring='r2')\n"
    "print(f'5-Fold CV Mean R2 Score: {cv_r2_scores.mean():.4f} (+/- {cv_r2_scores.std():.4f})')\n"
    "\n"
    "# Fit model on training set\n"
    "xgb_model.fit(X_train, y_train)\n"
    "\n"
    "# Evaluate on test set\n"
    "y_pred = xgb_model.predict(X_test)\n"
    "r2 = r2_score(y_test, y_pred)\n"
    "rmse = np.sqrt(mean_squared_error(y_test, y_pred))\n"
    "mae = mean_absolute_error(y_test, y_pred)\n"
    "\n"
    "print(f'Test Set R2: {r2:.4f} | RMSE: {rmse:.4f} | MAE: {mae:.4f}')\n"
)

# Save
doc.save(DOCX_PATH)
print("[OK] Data preparation & Model exploration DOCX populated successfully!")
print(f"   File saved to: {DOCX_PATH}")
print(f"   Total paragraphs: {len(doc.paragraphs)}")
